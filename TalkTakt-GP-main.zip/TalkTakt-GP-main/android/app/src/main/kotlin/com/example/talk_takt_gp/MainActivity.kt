package com.example.talk_takt_gp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
